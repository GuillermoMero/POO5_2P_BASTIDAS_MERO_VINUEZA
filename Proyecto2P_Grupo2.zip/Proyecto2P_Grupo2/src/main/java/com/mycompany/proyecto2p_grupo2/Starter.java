/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto2p_grupo2;

/**
 *
 * @author LENOVO
 */
public class Starter {
    public static void main(String[] args){
        Main.main(args);
    }
}
